# Hyperion v21.2 verification scaffold

This package extends v21.1 around the v21.2 hardening patch:

- `test_sustained_kv_stall.py` checks that sustained KV pager misses block descriptor acceptance and sequencer/core progress hooks.
- `test_quant_latency_alignment.py` checks that quant scale/zero-point controls are sampled with the operands and align with the two-cycle PE/MAC result contract.
- `test_rope_lut_rotation.py` checks the new 8-phase LUT RoPE scaffold is non-destructive and no longer the old 4-phase placeholder.
- `test_east_allreduce_fp_path.py` checks that east collectives have a configurable FP16 reference path under `cfg_allreduce_fp`.

Existing v21.1 tests for TMA stride geometry, pager fault/clear, quant modes, FlashAttention shape, and integration controls are retained. These tests are still cocotb-style scaffolds intended for use with Verilator/Icarus or a commercial simulator.
