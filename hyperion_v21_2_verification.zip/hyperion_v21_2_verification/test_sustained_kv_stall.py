import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

async def reset(dut):
    dut.rst_n.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)

@cocotb.test()
async def sustained_kv_miss_blocks_pager_clients(dut):
    """A miss must remain a hard stall across many cycles, not a one-cycle pulse."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    await reset(dut)

    # Cause a miss. The standalone pager exposes the architectural behavior that
    # the top level synchronizes into sequencer_kv_stall.
    dut.lookup_vpn.value = 0x77
    dut.lookup_valid.value = 1
    await RisingEdge(dut.clk)
    dut.lookup_valid.value = 0
    await RisingEdge(dut.clk)

    for _ in range(8):
        assert int(dut.pager_stall.value) == 1
        assert int(dut.fault_valid.value) == 1
        await RisingEdge(dut.clk)

    dut.ptw_write_valid.value = 1
    dut.ptw_write_index.value = 0x77
    dut.ptw_write_vpn.value = 0x77
    dut.ptw_write_ppn.value = 0x4567
    dut.ptw_write_valid_bit.value = 1
    dut.fault_clear.value = 1
    await RisingEdge(dut.clk)
    dut.ptw_write_valid.value = 0
    dut.fault_clear.value = 0
    await RisingEdge(dut.clk)
    assert int(dut.pager_stall.value) == 0
