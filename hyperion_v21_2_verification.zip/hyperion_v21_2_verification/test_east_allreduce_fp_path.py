def test_east_allreduce_has_fp16_reference_path():
    text = open("../HyperionNPUv21_2.sv").read()
    assert "module fp16_adder_ref" in text
    assert "u_east_allreduce_fp16" in text
    assert "cfg_allreduce_fp ? east_fp16_sum : east_raw_sum" in text
    assert "East collectives operate on 16-bit activation lanes" in text
