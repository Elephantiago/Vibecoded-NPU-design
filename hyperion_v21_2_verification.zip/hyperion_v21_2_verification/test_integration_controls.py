def test_v21_1_static_control_expectations():
    text = open("../HyperionNPUv21_2.sv", "r").read()
    assert "assign tma_desc_ready = tma_desc_ready_int && !sequencer_kv_stall" in text
    assert "assign core_step_root = east_obuf_ready && south_obuf_ready && sparse_meta_ready_for_step && !sequencer_kv_stall" in text
    assert ".dma_busy(dma_busy || sequencer_kv_stall)" in text
    assert ".array_busy(array_busy || sequencer_kv_stall)" in text
    assert "cfg_quant_scale_mode" in text
    assert "load_addr_full" in text
