import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

async def reset(dut):
    dut.rst_n.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)

@cocotb.test()
async def q88_quant_result_aligns_with_two_cycle_mac_contract(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    await reset(dut)

    dut.ce.value = 1
    dut.cfg_mode.value = 0       # INT16
    dut.cfg_mx_native_accum.value = 0
    dut.cfg_mx_finalize.value = 0
    dut.shared_exp.value = 127
    dut.cfg_quant_en.value = 1
    dut.cfg_quant_scale_mode.value = 1  # Q8.8
    dut.quant_scale_q8_8.value = 384    # 1.5x
    dut.quant_scale_fp32.value = 0x3FC00000
    dut.quant_bias_i32.value = 2
    dut.act_zero_point.value = 1
    dut.wt_zero_point.value = 2
    dut.sparse_meta.value = 0
    dut.c_accum.value = 5
    dut.a_in.value = 10  # weight, zero point 2 -> 8
    dut.b_in.value = 7   # activation, zero point 1 -> 6

    # Stage 1 samples operands/quant controls; Stage 2 emits result.
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    expected_acc = 5 + (8 * 6)
    expected = ((expected_acc * 384) >> 8) + 2
    assert int(dut.mac_out.value) == expected, f"got {int(dut.mac_out.value)} expected {expected}"
