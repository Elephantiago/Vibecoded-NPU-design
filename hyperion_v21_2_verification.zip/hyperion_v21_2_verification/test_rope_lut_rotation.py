import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

async def reset(dut):
    dut.rst_n.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)

@cocotb.test()
async def rope_lut_is_pipelined_and_non_destructive(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    await reset(dut)
    dut.cfg_rope_en.value = 1
    dut.m_tready.value = 1
    dut.s_tvalid.value = 1
    dut.s_tdata.value = 0x0002000100040003  # two signed 16-bit pairs
    await RisingEdge(dut.clk)
    dut.s_tdata.value = 0x0006000500080007
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    assert int(dut.m_tvalid.value) == 1
    assert int(dut.m_tdata.value) != 0

def test_v21_2_rope_static_lut():
    text = open("../HyperionNPUv21_2.sv").read()
    assert "cos_lut" in text
    assert "sin_lut" in text
    assert "rotate_pair_lut" in text
    assert "Q1.14" in text
