# Hyperion v21.1 verification scaffold

This package extends the v21 cocotb/UVM-lite scaffolding around the v21.1 fixes:

- `test_tma_stride.py` checks that the TMA uses `stride_m` and `stride_n` instead of linear +1 addressing.
- `test_kv_pager_fault.py` checks that a KV page miss becomes a visible fault/stall and clears after PTW repair.
- `test_quant_modes.py` checks fixed Q8.8 and FP32-scale quantization hooks through the MAC.
- `test_flashattn_rtl_golden.py` drives the RTL FlashAttention VPU path and compares against a Python reference with an explicit tolerance.
- `test_integration_controls.py` smoke-checks propagation of pager stalls into TMA/sequencer-facing readiness.

These tests are scaffolds intended for cocotb + Verilator/Icarus in an environment with an SV simulator installed.
