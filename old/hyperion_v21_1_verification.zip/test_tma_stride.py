import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

async def reset(dut):
    dut.rst_n.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)

@cocotb.test()
async def tma_uses_2d_strides(dut):
    """A 2x3 tile with stride_m=16 and stride_n=2 must not become linear +1."""
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    await reset(dut)

    dut.desc_base_addr.value = 0x20
    dut.desc_dim_m.value = 8
    dut.desc_dim_n.value = 8
    dut.desc_tile_m.value = 2
    dut.desc_tile_n.value = 3
    dut.desc_stride_m.value = 16
    dut.desc_stride_n.value = 2
    dut.desc_dst_kind.value = 0
    dut.desc_dst_bank.value = 0
    dut.hold.value = 0
    dut.stream_valid.value = 0
    dut.stream_data.value = 0
    dut.desc_valid.value = 1
    await RisingEdge(dut.clk)
    dut.desc_valid.value = 0

    expected = [0x20, 0x22, 0x24, 0x30, 0x32, 0x34]
    observed = []
    for i in range(len(expected) + 4):
        dut.stream_valid.value = 1
        dut.stream_data.value = i
        await RisingEdge(dut.clk)
        if int(dut.load_valid.value):
            observed.append(int(dut.load_addr_full.value))
    assert observed[:len(expected)] == expected, f"TMA stride addresses wrong: {observed}"
    assert int(dut.done.value) == 1
