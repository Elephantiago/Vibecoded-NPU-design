import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import struct

def f32_bits(x):
    return struct.unpack(">I", struct.pack(">f", float(x)))[0]

def bits_f32(x):
    return struct.unpack(">f", struct.pack(">I", int(x) & 0xffffffff))[0]

async def reset(dut):
    dut.rst_n.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)

@cocotb.test()
async def mac_quant_q88_and_fp32_scale_smoke(dut):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    await reset(dut)

    dut.ce.value = 1
    dut.cfg_mode.value = 0 # INT16
    dut.cfg_mx_native_accum.value = 0
    dut.cfg_mx_finalize.value = 0
    dut.shared_exp.value = 127
    dut.act_zero_point.value = 0
    dut.wt_zero_point.value = 0
    dut.sparse_meta.value = 0
    dut.c_accum.value = 0
    dut.a_in.value = 3
    dut.b_in.value = 4

    dut.cfg_quant_en.value = 1
    dut.cfg_quant_scale_mode.value = 1 # Q8.8
    dut.quant_scale_q8_8.value = 512 # 2.0
    dut.quant_scale_fp32.value = f32_bits(2.0)
    dut.quant_bias_i32.value = 1
    for _ in range(3):
        await RisingEdge(dut.clk)
    assert int(dut.mac_out.value) == 25  # (3*4)*2 + 1

    dut.cfg_quant_scale_mode.value = 2 # FP32 scale
    dut.quant_scale_fp32.value = f32_bits(0.5)
    dut.quant_bias_i32.value = 0
    for _ in range(3):
        await RisingEdge(dut.clk)
    got = bits_f32(dut.mac_out.value)
    assert abs(got - 6.0) < 0.75, f"FP scale path unexpected: {got}"
